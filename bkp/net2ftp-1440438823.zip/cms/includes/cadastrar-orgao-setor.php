<script type="text/javascript" src="js/cadastrar-orgao-setor.js"></script>
<section class="Centro Conteudo">
	<h1 class="TituloPagina">Cadastrar Orgão do Setor</h1><br/>
	
	<form name="cadorgao" method="post" onsubmit="return CadastrarOrgaoSetor(this)">	
		<div class="Linha">				
			<input type="text" name="title" class="Campo input" placeholder="Título: " style="width: 37.3%"/>						
		</div>
		
		<div class="Linha">				
			<input type="text" name="url" class="Campo input" placeholder="URL/Link: " style="width: 37.3%"/>						
		</div>	
		
		<div class="Linha">
			<input type="submit" value="Cadastrar" class="Campo Btn CadEmp AlterDs"/>
		</div>
		
		<div class="Linhainput resp">
			&nbsp;
		</div>
		<br/><br/>
	</form>
</section>