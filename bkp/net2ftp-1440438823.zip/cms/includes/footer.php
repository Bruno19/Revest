		<footer>
			<section class="Centro">
				<p class="TextoFooter">&copy; TODOS OS DIREITOS RESERVADOS<br/><br/>
			</section>
		</footer>