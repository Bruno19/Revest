<section class="Centro CentroConteudo">
	<br/>
	<h1 class="TituloPagina">Lista de Orgãos do setor cadastrados</h1>	
	<div class="CadCat">
		<br/>
		<table class="TabelaDeListas">
			<tbody>
				<tr>
					<th>ID</th>
					<th>Título</th>
					<th>Deletar</th>
					<th>Editar</th>
				</tr>
				<tr class="LinhatableImpar">
					<td colspan="5">&nbsp;</td>
				</tr>
			</tbody>
		</table>
		<br/><br/>
	</div>	
</section>

<script type="text/javascript" src="js/lista-orgao-setor.js"></script>
