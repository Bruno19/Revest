		<meta charset="utf-8"/>
		<meta name="author" content="Mega Support"/>
		<meta name="designer" content="Lucas Veríssimo"/>
		<title>Sistema de Gerenciamento do site</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all"/>
		<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>