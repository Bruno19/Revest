		<footer>
			<div class="Centro">
				<div class="info left" style="text-align: left">
					Copyrights &reg; - revestincena.com.br - (Produced by radiati.com.br)
				</div>			
				<div class="info right" style="text-align: right">
					<a href="#">Termos de Uso</a>
				</div>			
				<div class="esp"></div>
			</div>
		</footer>