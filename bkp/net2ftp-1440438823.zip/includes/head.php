
		<meta charset="utf-8"/>
		<meta name="author" content="Lucas Veríssimo / Bruno Ap."/>
		<meta name="designer" content="Lucas Veríssimo / Bruno Ap."/>
		<meta name="viewport" content="width=450"/>
		<title>IN Cena</title>
		<link rel="stylesheet" type="text/css" href="css/style.css" media="all"/>
		
		<link rel="stylesheet" type="text/css" href="css/mobile.css" media="all and (min-width: 400px) and (max-width: 599px)"/>
		<link rel="stylesheet" type="text/css" href="css/tablet.css" media="all and (min-width: 600px) and (max-width: 1023px)"/>
		<link rel="stylesheet" type="text/css" href="css/desktop.css" media="all and (min-width: 1024px)"/>		
		
		<script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
		