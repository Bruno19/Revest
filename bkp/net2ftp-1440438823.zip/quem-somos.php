<?php $pagename = "quem-somos";   ?>

<?php include_once('cms/php/conn.php'); mysqli_set_charset($conn, "utf8");?>
<!DOCTYPE html>
<html lang="pt-br">
	<head>
		<?php include_once('includes/head.php');?>		
	</head>
	<body>
		<?php include_once('includes/header.php');?>
		<?php include_once('includes/menu.php');?>
		
		
		<div class="Centro FundoConteudo">
			<img src="imagens/tit-quem-somos.jpg" alt="Quem Somos" class="Titulos TitulosGrandes right"/>
			
			<div class="BlocoConteudo1 BlocoQuemSomos right">
				<h2>Missão</h2>
				<br/>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut molestie purus. Aenean finibus iaculis suscipit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam iaculis dapibus arcu, eu condimentum diam placerat non.
				</p>
			</div>
			
			<div class="BlocoConteudo1 BlocoQuemSomos right">
				<h2>Visão</h2>
				<br/>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut molestie purus. Aenean finibus iaculis suscipit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam iaculis dapibus arcu, eu condimentum diam placerat non.
				</p>
			</div>
			
			<div class="BlocoConteudo1 BlocoQuemSomos right">
				<h2>Valores</h2>
				<br/>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ut molestie purus. Aenean finibus iaculis suscipit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam iaculis dapibus arcu, eu condimentum diam placerat non.
				</p>
			</div>
			
			
			<div class="esp"></div>
		</div>
		<?php include_once('includes/footer.php');?>
	</body>
</html>